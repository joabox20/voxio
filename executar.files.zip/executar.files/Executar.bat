@echo off
:: Configurações
chcp 65001 > nul
:: Paths
set "execfile=%USERPROFILE%\Documents\executar.files\data\exec"
set "datafile=%USERPROFILE%\Documents\executar.files\data"
set "fullnameextsn=%execfile%\fullname"
if not exist "%execfile%" mkdir "%execfile%" 2>nul
if not exist "%execfile%\fullname" (
    type nul > "%execfile%\fullname"
)
if not exist "%execfile%\stcolor" (
    type nul > "%execfile%\stcolor"
)
:: Pré-Comandos
set "execnum=9.0"
:: Caractere ESC (permite cores RGB com sequências ANSI no echo)
set "ESC="
for /f %%e in ('echo prompt $E ^| cmd') do set "ESC=%%e"
:: Paleta de cores
set "cRST=%ESC%[0m"
set "cBLD=%ESC%[1m"
set "cGRY=%ESC%[38;2;150;150;160m"
set "cWHT=%ESC%[38;2;235;235;240m"
set "cRED=%ESC%[38;2;255;95;95m"
set "cGRN=%ESC%[38;2;80;220;115m"
set "cYEL=%ESC%[38;2;255;215;70m"
set "cBLU=%ESC%[38;2;90;170;255m"
set "cCYN=%ESC%[38;2;75;215;240m"
set "cORG=%ESC%[38;2;255;140;0m"
set "rule=%cGRY%─────────────────────────%cRST%"
:: Está como administrador?
set "isadmin="
fltmc >nul 2>&1 && set "isadmin=1"
set "lastcmd="

:: Início
:st ::Nome abreviado para "start"

:: Intro
mode 63,12
title Executar
set "arquivostcolor=%execfile%\stcolor"
set "stcolor="
set /p stcolor=<"%arquivostcolor%"
set "stcolor=%stcolor: =%"
color %stcolor%
call :tema

echo.
echo %ESC%[38;2;%g1%m        █████ █   █ █████  ████ █   █ █████  ███  ████%cRST%
echo %ESC%[38;2;%g2%m        █      █ █  █     █     █   █   █   █   █ █   █%cRST%
echo %ESC%[38;2;%g3%m        ████    █   ████  █     █   █   █   █████ ████%cRST%
echo %ESC%[38;2;%g4%m        █      █ █  █     █     █   █   █   █   █ █  █%cRST%
echo %ESC%[38;2;%g5%m        █████ █   █ █████  ████  ███    █   █   █ █   █%cRST%
echo.
echo %ESC%[38;2;%g3%m        ───────────────────────────────────────────────%cRST%
echo %cGRY%                      Executar   %ESC%[38;2;%g3%m│%cGRY%   %cBLD%%ESC%[38;2;%g1%m%execnum%%cRST%
powershell -c "(New-Object Media.SoundPlayer '%execfile%\sound\tada.wav').PlaySync()" 2>nul

:: Preparo da Janela
cls
color f
mode 63,28
title Executar

:: Nome e Data Especial
set "fullname="
set /p fullname=<"%fullnameextsn%"
set "fullname=%fullname:"=%"
set "fullnametrim="
if defined fullname for /f "tokens=* delims= " %%A in ("%fullname%") do set "fullnametrim=%%A"
set "fullname=%fullnametrim%"
if defined fullname call :validar "%fullname%" || set "fullname="
if not defined fullname (
    echo %cYEL%[!]%cRST% Digite seu nome no arquivo "fullname" dentro da pasta "data" para colocar seu nome no programa.
    echo.
    goto barra
)

:: Data atual + Páscoa (calculada para o ano atual)
set "DIA="
set "MES="
set "PDIA="
set "PMES="
for /f "tokens=1-4" %%a in ('powershell -NoProfile -Command "$t=Get-Date;$y=$t.Year;$a=$y%%19;$b=[math]::Floor($y/100);$c=$y%%100;$d=[math]::Floor($b/4);$e=$b%%4;$f=[math]::Floor(($b+8)/25);$g=[math]::Floor(($b-$f+1)/3);$h=(19*$a+$b-$d-$g+15)%%30;$i=[math]::Floor($c/4);$k=$c%%4;$l=(32+2*$e+2*$i-$h-$k)%%7;$m=[math]::Floor(($a+11*$h+22*$l)/451);$n=$h+$l-7*$m+114;$pm=[math]::Floor($n/31);$pd=($n%%31)+1;Write-Output ($t.Day,$t.Month,$pd,$pm -join ' ')"') do (
    set "DIA=%%a"
    set "MES=%%b"
    set "PDIA=%%c"
    set "PMES=%%d"
)
set "msgExtra="
set "msgCol="
if "%DIA%"=="24" if "%MES%"=="12" (
    set "msgExtra=Feliz Natal!"
    set "msgCol=%cRED%"
)
if "%DIA%"=="25" if "%MES%"=="12" (
    set "msgExtra=Feliz Natal!"
    set "msgCol=%cRED%"
)
if "%DIA%"=="%PDIA%" if "%MES%"=="%PMES%" (
    set "msgExtra=Feliz Páscoa!"
    set "msgCol=%cYEL%"
)
if "%DIA%"=="31" if "%MES%"=="10" (
    set "msgExtra=Feliz Halloween!"
    set "msgCol=%cORG%"
)
if "%DIA%"=="1" if "%MES%"=="1" (
    set "msgExtra=Feliz Ano Novo!"
    set "msgCol=%cCYN%"
)
if "%DIA%"=="1" if "%MES%"=="4" (
    set "msgExtra=Hoje é o dia da verdade, confia..."
    set "msgCol=%cGRN%"
)

:: Boas-vindas
echo %cWHT%Olá, %cBLD%%fullname%%cRST%%cWHT%!%cRST%
if defined msgExtra echo %msgCol%%msgExtra%%cRST%
:: if defined isadmin echo %cGRN%● modo administrador%cRST%
echo.

:barra
:: ↓ Comandos que vão aparecer no comando "id"
set "comandosID=lo src sair rex cls id set bios win editar le cmd prog calc kill java app dat scan scan-sfc scan-dism scan-smrt dp wupd cfg pn tmp tm r"
set "input="
set /p "input=%ac%> %cRST%"
set "input=%input:"=%"
if not defined input goto barra
:: "r" repete o último comando
if /i not "%input%"=="r" goto cmdok
if not defined lastcmd (
    call :aviso "Ainda não há comando para repetir."
    goto barra
)
set "input=%lastcmd%"
echo %cGRY%repetindo: "%lastcmd%"%cRST%
:cmdok
set "lastcmd=%input%"
echo %rule%
:: Comandos
if /i "%input%"=="lo" explorer /select,"%~f0" & goto 1
if /i "%input%"=="src" goto search
if /i "%input%"=="sair" goto sair
if /i "%input%"=="rex" goto 3
if /i "%input%"=="cls" goto limpa
if /i "%input%"=="id" goto id
if /i "%input%"=="set" goto set
if /i "%input%"=="bios" goto bi
if /i "%input%"=="win" start winver
if /i "%input%"=="win" goto 1
if /i "%input%"=="editar" goto editar
if /i "%input%"=="le" goto lembrete
if /i "%input%"=="cmd" goto cmd
if /i "%input%"=="prog" goto program
if /i "%input%"=="calc" goto calc
if /i "%input%"=="kill" goto taskkill
if /i "%input%"=="java" goto java
if /i "%input%"=="app" goto app
if /i "%input%"=="dat" goto dat
if /i "%input%"=="scan-dism" goto dism
if /i "%input%"=="scan-sfc" goto sfc
if /i "%input%"=="scan-smrt" goto smartscan
if /i "%input%"=="scan" goto scanwarn
if /i "%input%"=="dp" goto diskpart
if /i "%input%"=="wupd" goto wupd
if /i "%input%"=="pn" goto ping
if /i "%input%"=="cfg" goto config
if /i "%input%"=="tmp" goto tmp
if /i "%input%"=="tm" goto tm

:: Comando não encontrado
echo %cRED%[X]%cRST% Comando "%input%" não encontrado.
echo %rule%
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\warn3.wav').PlaySync()"
goto barra

:: ============================================================
:: Sub-rotinas (usadas com "call")
:: ============================================================

:: Define o degradê (g1..g5) e as cores de destaque conforme %stcolor% (padrão = azul)
:tema
set "g1=120;200;255"
set "g2=90;170;255"
set "g3=60;140;255"
set "g4=40;110;245"
set "g5=25;80;225"
if "%stcolor%"=="c" (
    set "g1=255;150;150"
    set "g2=255;115;115"
    set "g3=255;85;85"
    set "g4=235;60;60"
    set "g5=200;40;40"
)
if "%stcolor%"=="a" (
    set "g1=150;255;170"
    set "g2=110;240;140"
    set "g3=80;220;115"
    set "g4=55;195;90"
    set "g5=35;165;70"
)
if "%stcolor%"=="e" (
    set "g1=255;245;150"
    set "g2=255;230;110"
    set "g3=255;215;70"
    set "g4=245;195;40"
    set "g5=225;170;20"
)
if "%stcolor%"=="b" (
    set "g1=150;250;255"
    set "g2=110;235;250"
    set "g3=75;215;240"
    set "g4=50;190;225"
    set "g5=30;160;200"
)
set "ac=%ESC%[38;2;%g3%m"
set "acl=%ESC%[38;2;%g1%m"
exit /b

:ok
echo %cGRN%[✓]%cRST% %~1
exit /b
:erro
echo %cRED%[X]%cRST% %~1
exit /b
:aviso
echo %cYEL%[!]%cRST% %~1
exit /b
:info
echo %ac%[i]%cRST% %~1
exit /b

:: Cabeçalho com a cor do tema
:cab
echo %ac%────────────────────────────────%cRST%
echo %acl%%cBLD%  %~1%cRST%
echo %ac%────────────────────────────────%cRST%
exit /b

:pausa
echo.
echo %cBLU%Pressione qualquer tecla para voltar...%cRST%
pause >nul
exit /b

:: Uso: call :validar "texto"  ->  retorna 1 se tiver & | < > ^
:validar
echo "%~1"| findstr /r /c:"[&|<>^]" >nul && exit /b 1
exit /b 0

:: Uso: call :precisaadmin || goto barra
:precisaadmin
if defined isadmin exit /b 0
call :aviso "Este comando precisa do Executar aberto como administrador."
exit /b 1

:precisajava
where java >nul 2>&1 && exit /b 0
call :erro "Java não encontrado. Instale o Java e tente novamente."
timeout /t 3 >nul
exit /b 1

:getjava
set "javer="
for /f "tokens=3" %%a in ('java -version 2^>^&1 ^| findstr /i "version"') do if not defined javer set "javer=%%~a"
if not defined javer set "javer=Java não encontrado"
exit /b

:getip
set "ipv4="
set "ipv6="
set "pingbase="
for /f "tokens=2 delims=:" %%i in ('ipconfig ^| findstr /i "IPv4"') do for /f "tokens=* delims= " %%a in ("%%i") do if not defined ipv4 set "ipv4=%%a"
for /f "tokens=1* delims=:" %%i in ('ipconfig ^| findstr /i "IPv6"') do for /f "tokens=1 delims=%% " %%c in ("%%j") do if not defined ipv6 set "ipv6=%%c"
if defined ipv4 for /f "tokens=1-3 delims=." %%a in ("%ipv4%") do set "pingbase=%%a.%%b.%%c"
exit /b

:: Entrada com caracteres que poderiam executar comandos extras
:invalido
call :erro "Entrada inválida: não use os caracteres & | < > ^"
timeout /t 2 >nul
goto barra

:: ============================================================
:: Comandos
:: ============================================================

:config
set "configsel=1"
if not exist "%execfile%\stcolor" >"%execfile%\stcolor" echo b
if not exist "%execfile%\fullname" >"%execfile%\fullname" echo.
:cfglp
set "configcolor="
set "configname="
set "configkey="
set /p "configcolor="<"%execfile%\stcolor"
if "%configcolor%"=="c" set "configname=Vermelho"
if "%configcolor%"=="1" set "configname=Azul"
if "%configcolor%"=="a" set "configname=Verde"
if "%configcolor%"=="e" set "configname=Amarelo"
if "%configcolor%"=="b" set "configname=Azul Claro"
if not defined configname (
    >"%execfile%\stcolor" echo c
    set "configcolor=c"
    set "configname=Vermelho"
)
set "stcolor=%configcolor%"
call :tema
set "configvalue=[%configname%]"
set "configvalue=%configvalue%               "
set "configvalue=%configvalue:~0,15%"
cls
echo %cBLU%Mexa com as setinhas ↑ ↓ → ←%cRST%
echo.
echo  +------------------------------+
if "%configsel%"=="1" (
    echo  ^| %acl%^> Mudar cor   %configvalue%%cRST%^|
) else (
    echo  ^|   Mudar cor   %configvalue%^|
)
if "%configsel%"=="2" (
    echo  ^| %acl%^> Mudar nome                 %cRST%^|
) else (
    echo  ^|   Mudar nome                 ^|
)
if "%configsel%"=="3" (
    echo  ^| %acl%^> Sair                       %cRST%^|
) else (
    echo  ^|   Sair                       ^|
)
echo  +------------------------------+
echo.
echo Cor do Início do Programa
echo %ESC%[38;2;%g1%m█%ESC%[38;2;%g2%m█%ESC%[38;2;%g3%m█%ESC%[38;2;%g4%m█%ESC%[38;2;%g5%m█%cRST% %acl%Executar%cRST% %cGRY%^|%cRST% %ac%%execnum%%cRST%
for /f "delims=" %%A in ('powershell -NoProfile -Command "$k=[Console]::ReadKey($true);$k.Key.ToString()"') do set "configkey=%%A"
if "%configkey%"=="UpArrow" (
    set /a configsel-=1
    if %configsel% LSS 1 set "configsel=3"
    goto cfglp
)
if "%configkey%"=="DownArrow" (
    set /a configsel+=1
    if %configsel% GTR 3 set "configsel=1"
    goto cfglp
)
if "%configkey%"=="LeftArrow" if "%configsel%"=="1" (
    if "%configcolor%"=="c" >"%execfile%\stcolor" echo b
    if "%configcolor%"=="1" >"%execfile%\stcolor" echo c
    if "%configcolor%"=="a" >"%execfile%\stcolor" echo 1
    if "%configcolor%"=="e" >"%execfile%\stcolor" echo a
    if "%configcolor%"=="b" >"%execfile%\stcolor" echo e
    goto cfglp
)
if "%configkey%"=="RightArrow" if "%configsel%"=="1" (
    if "%configcolor%"=="c" >"%execfile%\stcolor" echo 1
    if "%configcolor%"=="1" >"%execfile%\stcolor" echo a
    if "%configcolor%"=="a" >"%execfile%\stcolor" echo e
    if "%configcolor%"=="e" >"%execfile%\stcolor" echo b
    if "%configcolor%"=="b" >"%execfile%\stcolor" echo c
    goto cfglp
)
if "%configkey%"=="Enter" if "%configsel%"=="2" (
    notepad "%execfile%\fullname"
    goto cfglp
)
if "%configkey%"=="Enter" if "%configsel%"=="3" (
    cls
    goto :barra
)
if "%configkey%"=="Escape" (
    cls
    goto :barra
)
goto cfglp

:ping
call :getip
cls
call :cab "PING"
powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Balloon.wav').PlaySync()" 2>nul
echo.
echo %cGRY%[1]%cRST% Testar Host
echo %cGRY%[2]%cRST% Ver IPv4
echo %cGRY%[3]%cRST% Ver IPv6
echo %cGRY%[4]%cRST% Teste de alcance de IPs
echo %cGRY%[5]%cRST% Rastear Rota até o Host
echo.
set "pingut="
set /p "pingut=%ac%> %cRST%"
if "%pingut%"=="1" goto ping1
if "%pingut%"=="2" goto ping2
if "%pingut%"=="3" goto ping3
if "%pingut%"=="4" goto ping4
if "%pingut%"=="5" goto ping5
cls
goto barra
:ping1
cls
echo %cYEL%Digite seu host (IPv4, IPv6 ou URL) que deseja testar%cRST%
echo %cGRY%Ex.: google.com%cRST%
echo.
set "pingtest="
set /p pingtest=
set "pingtest=%pingtest:"=%"
if not defined pingtest goto ping
call :validar "%pingtest%" || goto invalido
ping -n 6 -w 2000 "%pingtest%"
call :pausa
goto ping
:ping2
cls
echo %cBLU%Seu IPv4 é:%cRST%
if defined ipv4 (echo %ipv4%) else (echo Não encontrado)
call :pausa
goto ping
:ping3
cls
echo %cBLU%Seu IPv6 é:%cRST%
if defined ipv6 (echo %ipv6%) else (echo Não encontrado)
call :pausa
goto ping
:ping4
cls
echo %cYEL%Teste de alcance: mostra quais IPs da rede respondem (1 a 254).%cRST%
echo %cGRY%Digite os 3 primeiros blocos da rede. Ex.: 192.168.0%cRST%
if defined pingbase echo Pressione Enter para usar a sua rede: %pingbase%
echo.
set "pingnet="
set /p pingnet=Rede: 
set "pingnet=%pingnet:"=%"
if not defined pingnet set "pingnet=%pingbase%"
if not defined pingnet goto ping
call :validar "%pingnet%" || goto invalido
echo %pingnet%| findstr /r "^[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*$" >nul || (
    call :erro "Formato inválido. Use algo como 192.168.0"
    timeout /t 3 >nul
    goto ping4
)
echo.
call :info "Varrendo a rede, aguarde..."
powershell -NoProfile -Command "$net=$env:pingnet; $jobs=1..254 | ForEach-Object { $ip=$net+'.'+$_; $p=New-Object System.Net.NetworkInformation.Ping; [pscustomobject]@{IP=$ip;Task=$p.SendPingAsync($ip,700)} }; [void][System.Threading.Tasks.Task]::WaitAll(@($jobs | ForEach-Object { $_.Task })); $up=@($jobs | Where-Object { $_.Task.Result.Status -eq 'Success' }); $up | ForEach-Object { Write-Host ($_.IP+' responde') -ForegroundColor Green }; Write-Host ($up.Count.ToString()+' de 254 IPs responderam.') -ForegroundColor Yellow"
call :pausa
goto ping
:ping5
cls
echo %cYEL%Digite o host (IPv4, IPv6 ou URL) para rastrear a rota%cRST%
echo %cGRY%Ex.: google.com%cRST%
echo.
set "pingtest="
set /p pingtest=
set "pingtest=%pingtest:"=%"
if not defined pingtest goto ping
call :validar "%pingtest%" || goto invalido
tracert -d -w 1000 "%pingtest%"
call :pausa
goto ping

:wupd
start control /name Microsoft.WindowsUpdate
goto 1

:tm
start "" taskmgr
goto 1

:tmp
call :aviso "Isto apaga os arquivos temporários do seu usuário (pasta TEMP)."
set "att="
set /p "att=Deseja continuar? (S/N) - "
if /i not "%att%"=="S" (
    cls
    goto barra
)
call :info "Limpando, aguarde..."
set "liberado=0"
for /f %%a in ('powershell -NoProfile -Command "$p=$env:TEMP; $b=(Get-ChildItem $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum; Get-ChildItem $p -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue; $a=(Get-ChildItem $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum; [math]::Round(($b-$a)/1MB,2)"') do set "liberado=%%a"
call :ok "Concluído! Espaço liberado: %liberado% MB (arquivos em uso são ignorados)."
echo %rule%
goto barra

:id
echo %cYEL%%comandosID%%cRST%
echo %rule%
goto barra

:sfc
call :precisaadmin || goto barra
sfc /scannow
set "rc=%errorlevel%"
goto fimreparo

:dism
call :precisaadmin || goto barra
DISM /Online /Cleanup-Image /RestoreHealth
set "rc=%errorlevel%"
goto fimreparo

:fimreparo
echo %rule%
if not "%rc%"=="0" (
    start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\warn3.wav').PlaySync()"
    call :erro "O comando terminou com erro - código %rc%. Veja a saída acima."
    echo %rule%
    goto barra
)
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\notify.wav').PlaySync()"
call :ok "Comando finalizado. Confira o resultado acima."
echo %rule%
goto barra

:smartscan
call :precisaadmin || goto barra
cls
call :info "Iniciando SmartScan"
timeout /t 1 >nul
cls
call :info "[1/3] Verificando arquivos do sistema (SFC)..."
sfc /scannow
set "rc1=%errorlevel%"
cls
call :info "[2/3] Reparando a imagem do Windows (DISM)..."
DISM /Online /Cleanup-Image /RestoreHealth
set "rc2=%errorlevel%"
cls
call :info "[3/3] Verificando novamente (SFC)..."
sfc /scannow
set "rc3=%errorlevel%"
echo %rule%
if "%rc1%%rc2%%rc3%"=="000" (
    start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\notify.wav').PlaySync()"
    call :ok "Smart Scan concluído sem erros!"
) else (
    start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\warn3.wav').PlaySync()"
    call :erro "Smart Scan terminou com avisos - SFC: %rc1% / DISM: %rc2% / SFC: %rc3%."
)
call :pausa
cls
goto barra

:scanwarn
cls
call :aviso "Opa! Tem um parâmetro faltando aí"
echo Tente: scan-sfc, scan-dism ou scan-smrt
powershell -c "(New-Object Media.SoundPlayer '%execfile%\sound\warn3.wav').PlaySync()" 2>nul
timeout /t 10 >nul
cls
goto barra

:diskpart
cls
call :aviso "O modo DISKPART fica fixo desde que o programa seja reiniciado."
powershell -c "(New-Object Media.SoundPlayer '%execfile%\sound\warn2.wav').PlaySync()" 2>nul
set "at2="
set /p "at2=Deseja continuar? (S/N) - "
if /i "%at2%"=="S" goto diskaccept
cls
goto barra
:diskaccept
cls
DISKPART
goto diskaccept

:app
set "apppath=%execfile%\hta"
set "appjson=%apppath%\app.json"
set "apphta=%apppath%\app.hta"

if not exist "%appjson%" (
    start "" "%apphta%"
    goto barra
)
set "appmode="
for /f "usebackq delims=" %%a in (`powershell -NoProfile -Command "Get-Content '%appjson%' | Where-Object { $_ -and -not $_.StartsWith('##') } | Select-Object -First 1"`) do set "appmode=%%a"
if /i "%appmode%"=="config" (
    start "" "ms-settings:appsfeatures"
    call :ok "Aplicativos Instalados no App de Configurações executado com sucesso!"
    goto barra
)
if /i "%appmode%"=="control" (
    start "" appwiz.cpl
    call :ok "Programas e Recursos no Painel de Controle executado com sucesso!"
    goto barra
)
start "" "%apphta%"
goto barra

:dat
cls
call :cab "Abrindo [data]"
timeout /t 1 >nul
start "" "%execfile%"
cls
goto barra

:java
if not defined javer call :getjava
cls
call :cab "JAVA"
echo %cGRY%Versão: %javer%%cRST%
echo.
echo %cWHT%[1] Executar um programa jar%cRST%
echo %cWHT%[2] Executar um comando Java%cRST%
echo %cRED%[3] Voltar%cRST%
echo.
set "javaput="
set /p "javaput=%ac%> %cRST%"
if "%javaput%"=="1" goto jar-program
if "%javaput%"=="2" goto java-command
if "%javaput%"=="3" cls & goto barra
goto java
:jar-program
call :precisajava || goto java
cls
set "tempfile=%temp%\jarpath.txt"
if exist "%tempfile%" del "%tempfile%"
powershell -NoProfile -STA -Command "Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title='Selecione o arquivo JAR'; $d.Filter='Arquivos JAR (*.jar)|*.jar'; if($d.ShowDialog() -eq 'OK'){ [System.IO.File]::WriteAllText('%tempfile%',$d.FileName,(New-Object System.Text.UTF8Encoding $false)) }"
if not exist "%tempfile%" (
    call :erro "Nenhum arquivo selecionado."
    timeout /t 7 >nul
    cls
    goto barra
)
set "javalocal="
set /p javalocal=<"%tempfile%"
del "%tempfile%"
echo Arquivo selecionado:
echo %javalocal%
echo.
java -jar "%javalocal%"
call :pausa
goto java
:java-command
call :precisajava || goto java
cls
echo %cYEL%Execute seu comando java%cRST%
echo.
set "javaop="
set /p javaop=java 
set "javaop=%javaop:"=%"
call :validar "%javaop%" || goto invalido
echo.
echo %rule%
java %javaop%
echo %rule%
call :pausa
goto java

:taskkill
call :aviso "O Matador de Tarefas irá forçar fechar a janela selecionada. Em um App como Bloco de Notas do Windows ele fechará imediatamente sem nem mesmo ele perguntar se você quer salvar o arquivo."
echo %rule%
set "kill="
set /p kill=Tarefa: 
set "kill=%kill:"=%"
echo %rule%
if not defined kill goto barra
call :validar "%kill%" || goto invalido
taskkill /f /im "%kill%"
if errorlevel 1 (
    call :erro "Não foi possível encerrar a tarefa."
) else (
    call :ok "Tarefa encerrada."
)
timeout /t 2 >nul
goto barra

:program
cls
echo %cBLU%Isso é similar ao Executar [Win+R] então, digite um nome que o Executar irá reconhecer. Lembre-se que nem todo programa funcionará. Exemplos: explorer, cmd, control, appwiz.cpl, devmgmt.msc, diskpart%cRST%
set "pinput="
set /p pinput=Programa: 
set "pinput=%pinput:"=%"
if not defined pinput goto barra
call :validar "%pinput%" || goto invalido
start "" %pinput%
cls
goto barra

:calc
call :info "Abrindo a Calculadora..."
echo %rule%
powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Unlock.wav').PlaySync()" 2>nul 
start "" "%execfile%\hta\calc.hta"
goto barra

:search
cls
echo %cGRN%Pode escrever bastante coisa! ele vai preparar o link e já mandar na pesquisa do Google%cRST%
echo %cYEL%digite "back" para voltar%cRST%
echo.
set "entrada="
set /p entrada=Pesquisa: 
set "entrada=%entrada:"=%"
cls
if /i "%entrada%"=="back" goto barra
if not defined entrada goto search
set "termo="
for /f "delims=" %%a in ('powershell -NoProfile -Command "[uri]::EscapeDataString($env:entrada)"') do set "termo=%%a"
start "" "https://www.google.com/search?q=%termo%"
echo %cBLU%"%entrada%" pesquisado!%cRST%
timeout /t 2 /nobreak > nul
cls
goto search

:cmd
call :aviso "O modo CMD fica fixo desde que o programa seja reiniciado."
powershell -c "(New-Object Media.SoundPlayer '%execfile%\sound\warn2.wav').PlaySync()" 2>nul
set "at="
set /p "at=Deseja continuar? (S/N) - "
if /i "%at%"=="S" goto cmdaccept
cls
goto barra
:cmdaccept
cls
cmd
echo.
goto cmdaccept

:editar
call :info "Vamos editar!"
echo %rule%
powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Notify Email.wav').PlaySync()" 2>nul
rundll32.exe shell32.dll,OpenAs_RunDLL "%~f0"
timeout /t 1 >nul
exit

:bi
call :aviso "O computador vai reiniciar e abrir a BIOS/UEFI. Salve seus arquivos antes."
set "atb="
set /p "atb=Deseja continuar? (S/N) - "
if /i not "%atb%"=="S" (
    cls
    goto barra
)
call :info "Indo para a BIOS - para cancelar, digite: shutdown /a"
echo %rule%
shutdown /r /fw /t 5 /c "Indo para a BIOS. O dispositivo sera desligado em 5 segundos."
goto barra

:set
cls
call :info "Lendo peças e componentes do sistema..."
start "" /min powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Pop-up Blocked.wav').PlaySync()"
echo.
powershell -NoProfile -Command "function L($k,$v){Write-Host ($k.PadRight(24)) -NoNewline -ForegroundColor Cyan; Write-Host $v}; $cpu=Get-CimInstance Win32_Processor | Select-Object -First 1; $os=Get-CimInstance Win32_OperatingSystem; $cs=Get-CimInstance Win32_ComputerSystem; $d=Get-PSDrive C; $tot=$d.Used+$d.Free; $pct=[int][math]::Round($d.Used/$tot*100); $bar=('█'*[int]($pct/5)).PadRight(20,'░'); $b=[int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuild; if($b -ge 22000){$w='Windows 11'}elseif($b -ge 19041){$w='Windows 10'}else{$w=$os.Caption}; $cmdv=(Get-Item (Get-Command cmd).Source).VersionInfo.FileVersion; L 'CPU' $cpu.Name; L 'RAM (utilizável)' ([math]::Round($cs.TotalPhysicalMemory/1GB,2).ToString()+' GB'); L 'Disco C' ('{0:N2} GB total, {1:N2} GB usado, {2:N2} GB livre' -f ($tot/1GB),($d.Used/1GB),($d.Free/1GB)); L 'Uso do disco' ($bar+' '+$pct+'%%'); L 'Sistema operacional' $w; L 'Núcleo do sistema' 'Windows_NT'; L 'Versão Kernel e Win' $cmdv; L 'Versão do PowerShell' $PSVersionTable.PSVersion.ToString(); L 'Arq. do processador' ($cpu.AddressWidth.ToString()+' bits'); L 'Arq. do sistema' $os.OSArchitecture; Get-CimInstance Win32_VideoController | ForEach-Object { L 'GPU' $_.Name }"
echo %rule%
call :pausa
goto barra

:3
call :info "Reiniciando [explorer.exe]"
echo %rule%
taskkill /f /im explorer.exe > nul
start explorer.exe > nul
goto barra

:limpa
call :info "Limpando..."
echo %rule%
timeout /t 1 /nobreak > nul
cls
goto barra

:1
call :ok "Executado com sucesso!"
echo %rule%
goto barra

:lembrete
cls
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Message Nudge.wav').PlaySync()"
call :cab "Criador de Lembretes"
:perguntarlembrete
set "respostaLembretes="
set /p respostaLembretes=Você quer fazer um lembrete? (S/N): 
if /I "%respostaLembretes%"=="S" (
    cls
    goto criarLembrete
) else if /I "%respostaLembretes%"=="N" (
    cls
    goto barra
) else (
    start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\warn3.wav').PlaySync()"
    call :aviso "Resposta inválida. Digite apenas S ou N."
    timeout /t 2 >nul
    cls
    goto perguntarlembrete
)
:criarLembrete
cls
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Hardware Fail.wav').PlaySync()"
call :cab "Crie um Lembrete!"
echo %cGRY%Digite o conteúdo do lembrete, ele será colocado na Área de Trabalho.%cRST%
set "desktopPath=%USERPROFILE%\Desktop"
set "arquivoNum=1"
:checaArquivolembretes
if exist "%desktopPath%\lembrete_%arquivoNum%.txt" (
    set /a arquivoNum+=1
    goto checaArquivolembretes
)
set "arquivo=%desktopPath%\lembrete_%arquivoNum%.txt"
if not exist "%arquivo%" type nul > "%arquivo%"
start "" notepad "%arquivo%"
echo.
echo Escreva o lembrete, salve no Bloco de Notas e depois
echo pressione qualquer tecla aqui para continuar...
pause >nul
cls
:lembreteFinal
(
    echo LEMBRETE %arquivoNum%
    echo -----------------------------
    type "%arquivo%"
) > "%desktopPath%\temp_lembrete.txt"
move /y "%desktopPath%\temp_lembrete.txt" "%arquivo%" >nul
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Notify Calendar.wav').PlaySync()"
for %%F in ("%arquivo%") do (
    set "lemTam=%%~zF"
    set "lemNome=%%~nxF"
    set "lemLocal=%%~fF"
)
call :cab "Lembrete Criado!"
echo %cGRY%Tamanho do Arquivo:%cRST% %lemTam% Bytes
echo %cGRY%Nome do Arquivo:%cRST% %lemNome%
echo %cGRY%Local do Arquivo:%cRST% %lemLocal%
timeout /t 10 >nul
cls
goto barra

:: Fechar Programa
:sair
start "" /min powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Alarm03.wav').PlaySync()" 
echo %cBLU%Tchau!%cRST%
timeout /t 1 >nul
exit