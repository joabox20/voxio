@echo off
:: Configurações
chcp 65001 > nul
:: Paths
set "create-path=%~dp0\data\exec-creating\"
set "execfile=%USERPROFILE%\Documents\executar.files\data\exec"
set "datafile=%USERPROFILE%\Documents\executar.files\data"
set "fullnameextsn=%execfile%\fullname"
if not exist "%execfile%\fullname" (
    type nul > "%execfile%\fullname"
)
if not exist "%execfile%\stcolor" (
    type nul > "%execfile%\stcolor"
)
:: Pré-Comandos
set "cor=powershell -NoProfile -Command Write-Host -ForegroundColor"
for /f "tokens=2 delims=:" %%i in ('ipconfig ^| findstr /i "IPv4"') do for /f "tokens=* delims= " %%a in ("%%i") do set ipv4=%%a
for /f "tokens=* delims= " %%i in ('ipconfig ^| findstr /i "IPv6"') do for /f "tokens=2* delims=:" %%a in ("%%i") do for /f "tokens=1 delims=%%" %%b in ("%%b") do set ipv6=%%b
for /f "tokens=3" %%a in ('java -version 2^>^&1 ^| findstr /i "version"') do (
    set "javer=%%~a"
)
set "javer=%javer:"=%"
set "execver=Executar.bat ^|^ Versão: 8.2"

:: Início
:st ::Nome abreviado para "start"

:: Intro
mode 26,2
title Executar
set "arquivostcolor=%execfile%\stcolor"
set /p stcolor=<"%arquivostcolor%"
color %stcolor%
echo %execver%
powershell -c "(New-Object Media.SoundPlayer '%execfile%\sound\tada.wav').PlaySync()" 2>nul

:: Preparo da Janela
cls
color f
mode 63,28
title Executar

:: Nome e Data Especial
set /p fullname=<"%fullnameextsn%"
for /f "tokens=* delims= " %%A in ("%fullname%") do set "fullname=%%A"
set "msg=Digite seu nome no arquivo "fullname" dentro da pasta "data" para colocar seu nome no programa."
if "%fullname%"=="" echo %msg% & echo. & goto barra
for /f %%a in ('powershell -NoProfile -Command "(Get-Date).Day"') do set DIA=%%a
for /f %%a in ('powershell -NoProfile -Command "(Get-Date).Month"') do set MES=%%a
if "%DIA%"=="24" if "%MES%"=="12" (
    set "msgExtra=Feliz Natal!"
    set "msgColor=Red"
)
if "%DIA%"=="25" if "%MES%"=="12" (
    set "msgExtra=Feliz Natal!"
    set "msgColor=Red"
)
if "%DIA%"=="20" if "%MES%"=="4" (
    set "msgExtra=Feliz Páscoa!"
    set "msgColor=Yellow"
)
if "%DIA%"=="31" if "%MES%"=="10" (
    set "msgExtra=Feliz Halloween!"
    set "msgColor=DarkYellow"
)
if "%DIA%"=="1" if "%MES%"=="1" (
    set "msgExtra=Feliz Ano Novo!"
    set "msgColor=Cyan"
)
if "%DIA%"=="1" if "%MES%"=="4" (
    set "msgExtra=Hoje é o dia da verdade, confia..."
    set "msgColor=Green"
)

:: Boas-vindas
echo Olá, %fullname%!
if defined msgExtra (
    powershell -NoProfile -Command ^
    "Write-Host '%msgExtra%' -ForegroundColor %msgColor%"
)
echo.

:barra
:: ↓ Comandos que vão aparecer no comando "id"
set comandosID=lo src sair rex cls id set bios win editar le cmd prog calc kill java app dat scan-sfc scan-dism scan-smrt dp wupd cfg pn
set /p input=^> 
echo -------------------------
:: Comandos
if /i "%input%"=="lo" explorer /select,"%~f0" & goto 1
if /i "%input%"=="src" goto search
if /i "%input%"=="sair" goto sair
if /i "%input%"=="rex" goto 3
if /i "%input%"=="cls" goto limpa
if /i "%input%"=="id" goto id
if /i "%input%"=="set" goto set
if /i "%input%"=="bios" goto bi
if /i "%input%"=="win" start winver
if /i "%input%"=="win" goto 1
if /i "%input%"=="editar" goto editar
if /i "%input%"=="le" goto lembrete
if /i "%input%"=="cmd" goto cmd
if /i "%input%"=="prog" goto program
if /i "%input%"=="calc" goto calc
if /i "%input%"=="kill" goto taskkill
if /i "%input%"=="java" goto java
if /i "%input%"=="app" goto app
if /i "%input%"=="dat" goto dat
if /i "%input%"=="scan-dism" goto dism
if /i "%input%"=="scan-sfc" goto sfc
if /i "%input%"=="scan-smrt" goto smartscan
if /i "%input%"=="scan" goto scanwarn
if /i "%input%"=="dp" goto diskpart
if /i "%input%"=="wupd" goto wupd
if /i "%input%"=="pn" goto ping
if /i "%input%"=="cfg" goto config

:: Comando não encontrado
%cor% Red [X] Comando "`""%input%"`"" não encontrado.
echo -------------------------
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\warn3.wav').PlaySync()"
goto barra

:: Comandos
:config
set "configsel=1"
if not exist "%execfile%\stcolor" >"%execfile%\stcolor" echo b
if not exist "%execfile%\fullname" >"%execfile%\fullname"
:cfglp
set "configcolor="
set /p "configcolor="<"%execfile%\stcolor"
if "%configcolor%"=="c" set "configname=Vermelho"
if "%configcolor%"=="1" set "configname=Azul"
if "%configcolor%"=="a" set "configname=Verde"
if "%configcolor%"=="e" set "configname=Amarelo"
if "%configcolor%"=="b" set "configname=Azul Claro"
if not defined configname (
    >"%execfile%\stcolor" echo c
    set "configcolor=c"
    set "configname=Vermelho"
)
set "configvalue=[%configname%]"
set "configvalue=%configvalue%               "
set "configvalue=%configvalue:~0,15%"
cls
%cor% Blue Mexa com as setinhas ↑ ↓ → ←
echo.
echo  +------------------------------+
if "%configsel%"=="1" (
    echo  ^| ^> Mudar cor   %configvalue%^|
) else (
    echo  ^|   Mudar cor   %configvalue%^|
)
if "%configsel%"=="2" (
    echo  ^| ^> Mudar nome                 ^|
) else (
    echo  ^|   Mudar nome                 ^|
)
if "%configsel%"=="3" (
    echo  ^| ^> Sair                       ^|
) else (
    echo  ^|   Sair                       ^|
)
echo  +------------------------------+
echo.
echo Cor do Início do Programa
powershell -NoProfile -Command "$c=(Get-Content '%execfile%\stcolor' -Raw).Trim(); $map=@{'c'='Red';'1'='Blue';'a'='Green';'e'='Yellow';'b'='Cyan'}; Write-Host $env:EXECVER -ForegroundColor $map[$c]"
for /f "delims=" %%A in ('powershell -NoProfile -Command "$k=[Console]::ReadKey($true);$k.Key.ToString()"') do set "configkey=%%A"
if "%configkey%"=="UpArrow" (
    set /a configsel-=1
    if %configsel% LSS 1 set "configsel=3"
    goto cfglp
)
if "%configkey%"=="DownArrow" (
    set /a configsel+=1
    if %configsel% GTR 3 set "configsel=1"
    goto cfglp
)
if "%configkey%"=="LeftArrow" if "%configsel%"=="1" (
    if "%configcolor%"=="c" >"%execfile%\stcolor" echo b
    if "%configcolor%"=="1" >"%execfile%\stcolor" echo c
    if "%configcolor%"=="a" >"%execfile%\stcolor" echo 1
    if "%configcolor%"=="e" >"%execfile%\stcolor" echo a
    if "%configcolor%"=="b" >"%execfile%\stcolor" echo e
    goto cfglp
)
if "%configkey%"=="RightArrow" if "%configsel%"=="1" (
    if "%configcolor%"=="c" >"%execfile%\stcolor" echo 1
    if "%configcolor%"=="1" >"%execfile%\stcolor" echo a
    if "%configcolor%"=="a" >"%execfile%\stcolor" echo e
    if "%configcolor%"=="e" >"%execfile%\stcolor" echo b
    if "%configcolor%"=="b" >"%execfile%\stcolor" echo c
    goto cfglp
)
if "%configkey%"=="Enter" if "%configsel%"=="2" (
    notepad "%execfile%\fullname"
    goto cfglp
)
if "%configkey%"=="Enter" if "%configsel%"=="3" (
    cls
    goto :barra
)
if "%configkey%"=="Escape" (
    cls
    goto :barra
)
goto cfglp

:ping
cls
%cor% DarkGray -------------------------
%cor% DarkYellow `t PING
%cor% DarkGray -------------------------
powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Balloon.wav').PlaySync()" 2>nul
echo.
echo [1] Testar Host
echo [2] Ver IPv4
echo [3] Ver IPv6
echo [4] Teste de alcance de IPs
echo [5] Rastear Rota até o Host
echo.
set /p pingut=^> 
if %pingut% == 1 goto ping1
if %pingut% == 2 goto ping2
if %pingut% == 3 goto ping3
goto barra
:ping1
cls
%cor% Yellow 'Digite seu host (IPv4, IPv6 ou URL) que deseja testar'"
%cor% DarkGray Ex.: google.com
echo.
set /p pingtest=
ping -n 6 -w 2000 %pingtest%
timeout /t 10 >nul
goto ping
:ping2
cls
%cor% Blue Seu IPv4 é:
echo %ipv4%
timeout /t 15 >nul
goto ping
:ping3
%cor% Blue Seu IPv6 é:
echo %ipv6%
timeout /t 15 >nul
goto ping

:wupd
start control /name Microsoft.WindowsUpdate
goto 1

:id
%cor% Yellow %comandosID%
echo -------------------------
goto barra

:sfc
sfc /scannow
echo -------------------------
goto 2

:smartscan
cls
%cor% Blue ^>^ Iniciando SmartScan ^<^
timeout /t 1 >nul
cls
sfc /scannow
cls
DISM /Online /Cleanup-Image /RestoreHealth
cls
sfc /scannow
echo -------------------------
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\notify.wav').PlaySync()"
%cor% Green Smart Scan concluído com sucesso!
timeout /t 2 >nul
cls
%cor% Blue Pressione [Enter] para continuar...
timeout /t 20 >nul
cls
goto barra

:dism
DISM /Online /Cleanup-Image /RestoreHealth
echo -------------------------
goto 2

:scanwarn
cls
%cor% Red [!] Opa! Tem um parâmetro faltando aí
echo Tente: scan-sfc, scan-dism ou scan-smrt
powershell -c "(New-Object Media.SoundPlayer '%execfile%\sound\warn3.wav').PlaySync()" 2>nul
timeout /t 10 >nul
cls
goto barra

:diskpart
cls
echo [ATENÇÃO] O modo DISKPART fica fixo desde que o programa seja reiniciado. Deseja continuar^? (S/N)
powershell -c "(New-Object Media.SoundPlayer '%execfile%\sound\warn2.wav').PlaySync()" 2>nul
set /p at2=(S/N) - 
if /i %at2% == S goto diskaccept
if /i %at2% == N cls & goto barra
goto barra
:diskaccept
cls
DISKPART
goto diskaccept

:app
set "apppath=%execfile%\hta"
set "appjson=%apppath%\app.json"
set "apphta=%apppath%\app.hta"

if not exist "%appjson%" (
    start "" "%apphta%"
    goto barra
)
set "appmode="
for /f "usebackq delims=" %%a in (`
    powershell -NoProfile -Command ^
    "Get-Content '%appjson%' | Where-Object { $_ -and -not $_.StartsWith('##') } | Select-Object -First 1"
`) do set "appmode=%%a"
if /i "%appmode%"=="config" (
    start "" "ms-settings:appsfeatures"
	echo Aplicativos Instalados no App de Configurações executado com sucesso!
    goto barra
)
if /i "%appmode%"=="control" (
    start "" appwiz.cpl
    echo Programas e Recursos no Painel de Controle executado com sucesso!
	goto barra
)
start "" "%apphta%"
goto barra

:dat
cls
%cor% DarkGray -------------------------
%cor% Blue Abrindo [data]
%cor% DarkGray -------------------------
timeout /t 1 >nul
start %execfile%
cls
goto barra

:java
cls
%cor% DarkGray -=-=-=-=-=-=-=-=-=-=-=-=-
%cor% Blue `t Java
%cor% DarkGray -=-=-=-=-=-=-=-=-=-=-=-=-
%cor% Gray Versão: %javer%
echo.
%cor% White [1] Executar um programa jar
%cor% White [2] Executar um comando Java
%cor% Red [3] Voltar
echo.
set /p javaput=^> 
if %javaput% == 1 goto jar-program
if %javaput% == 2 goto java-command
if %javaput% == 3 cls & goto barra
goto java
:jar-program
cls
setlocal EnableExtensions
set "tempfile=%temp%\jarpath.txt"
if exist "%tempfile%" del "%tempfile%"
powershell -NoProfile -STA -Command "Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title='Selecione o arquivo JAR'; $d.Filter='Arquivos JAR (*.jar)|*.jar'; if($d.ShowDialog() -eq 'OK'){ $d.FileName | Out-File -Encoding UTF8 '%tempfile%' }"
if not exist "%tempfile%" (
    %cor% Red Nenhum arquivo selecionado.
    timeout /t 7 >nul
	cls
    goto barra
)
set /p javalocal=<"%tempfile%"
del "%tempfile%"
echo Arquivo selecionado:
echo %javalocal%
echo.
java -jar "%javalocal%"
goto java
:java-command
cls
%cor% Yellow Execute seu comando java
echo.
set /p javaop=java 
echo.
%cor% DarkGray -------------------------------
java %javaop%
%cor% DarkGray -------------------------------
%cor% Blue Pressione [Enter] para voltar
timeout /t 99999 >nul
goto java
:: =-=-=-=
goto barra

:taskkill
echo Matador de Tarefas
echo O Matador de Tarefas irá forçar fechar a janela selecionada. Em um App como Bloco de Notas do Windows ele fechará imediatamente sem nem mesmo ele perguntar se você quer salvar o arquivo.
echo -------------------------
set /p kill=Tarefa: 
echo -------------------------
taskkill /f /im %kill%
timeout /t 1 >nul
goto barra

:program
cls
%cor% Blue Isso é similar ao Executar [Win+R] então, digite um nome que o Executar irá reconhecer. Lembre-se que nem todo programa funcionará. Exemplos: explorer, cmd, control, appwiz.cpl, devmgmt.msc, diskpart
set /p pinput=Programa: 
start %pinput%
cls
goto barra

:calc
%cor% Blue Abrindo a Calculadora...
echo -------------------------
powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Unlock.wav').PlaySync()" 2>nul 
start "" "%execfile%\hta\calc.hta"
goto barra

:search
cls
%cor% Green Pode escrever bastante coisa! ele vai preparar o link e já mandar na pesquisa do Google
%cor% Yellow digite "`""back"`"" para voltar
echo.
set /p entrada=Pesquisa: 
cls
if /i "%entrada%"=="back" goto barra
set "termo=%entrada: =+%"
start "" "https://www.google.com/search?q=%termo%"
%cor% Blue "%termo%" pesquisado!
timeout /t 2 /nobreak > nul
cls
goto search

:cmd
echo [ATENÇÃO] O modo CMD fica fixo desde que o programa seja reiniciado. Deseja continuar^? (S/N)
powershell -c "(New-Object Media.SoundPlayer '%execfile%\sound\warn2.wav').PlaySync()" 2>nul
set /p at=(S/N) - 
if /i %at% == S goto cmdaccept
if /i %at% == N cls & goto barra
goto barra
:cmdaccept
cls
cmd
echo.
goto cmdaccept

:editar
%cor% Blue Vamos editar!
echo -------------------------
powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Notify Email.wav').PlaySync()" 2>nul

    rundll32.exe shell32.dll,OpenAs_RunDLL %USERPROFILE%\Documents\executar.files\Executar.bat
timeout /t 1 >nul
exit

:bi
echo Indo para a BIOS
echo -------------------------
shutdown /r /fw /t 5 /c "Indo para a BIOS. O dispositivo sera desligado em 5 segundos."
goto barra

:set
cls
echo Lendo peças e componentes do sistema...
start "" /min powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Pop-up Blocked.wav').PlaySync()" 
timeout /t 1 /nobreak > nul
@echo on
:: CPU e Arch
for /f "delims=" %%a in ('powershell -NoProfile -Command "(Get-CimInstance Win32_Processor | Select-Object -First 1).Name"') do set "CPU=%%a"
for /f "delims=" %%a in ('powershell -NoProfile -Command "(Get-CimInstance Win32_Processor | Select-Object -First 1).AddressWidth"') do set "CPUArch=%%a"
:: RAM
for /f "delims=" %%a in ('powershell -NoProfile -Command "[math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2)"') do set "RAM=%%a"
:: Disco C
for /f "delims=" %%a in ('powershell -NoProfile -Command "$c=Get-PSDrive C; '{0:N2},{1:N2},{2:N2}' -f ($c.Used/1GB),($c.Free/1GB),(($c.Used+$c.Free)/1GB)"') do (
    for /f "tokens=1,2,3 delims=," %%x in ("%%a") do (
        set "DiscoUsado=%%x"
        set "DiscoLivre=%%y"
        set "DiscoTotal=%%z"
    )
)
:: PowerShell e CMD
for /f "delims=" %%a in ('powershell -NoProfile -Command "try { $PSVersionTable.PSVersion.ToString() } catch { Write-Output ''Nao foi possivel detectar o PowerShell'' }"') do set "PSVersion=%%a"
for /f "delims=" %%a in ('powershell -NoProfile -Command "try { (Get-Item (Get-Command cmd).Source).VersionInfo.FileVersion } catch { Write-Output ''Nao foi possivel encontrar o prompt de comando'' }"') do set "NTWVersion=%%a"
:: SO
for /f "delims=" %%a in ('powershell -NoProfile -Command "(Get-CimInstance Win32_OperatingSystem).OSArchitecture"') do set "OSArch=%%a"
for /f "delims=" %%a in ('powershell -NoProfile -Command "$b=(Get-ItemProperty ''HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'').CurrentBuild; if ($b -ge 22000) { Write-Output ''Windows 11'' } elseif ($b -ge 19041) { Write-Output ''Windows 10'' } else { Write-Output (Get-ItemProperty ''HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'').ProductName }"') do set "OSVersion=%%a"
:: ECHOs
@echo off
cls
echo CPU: %CPU%
echo RAM (UTILIZÁVEL): %RAM% GB
echo Disco C: %DiscoTotal% GB total, %DiscoUsado% GB usado, %DiscoLivre% GB livre
echo Núcleo do Sistema: Windows_NT
echo Versão Kernel e Win: %NTWVersion%
echo Versão do PowerShell: %PSVersion%
echo Arquitetura do processador: %CPUArch% bits
echo Arquitetura do sistema operacional: %OSArch%
setlocal enabledelayedexpansion
:: GPUs
set GPUCount=0
for /f "delims=" %%a in ('powershell -NoProfile -Command "Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name"') do (
    echo GPU: %%a
)
endlocal
echo -------------------------
echo Pressione Enter para voltar...
timeout /t 100 > nul
goto barra


:3
echo Reiniciando [explorer.exe]
echo -------------------------
taskkill /f /im explorer.exe > nul
start explorer.exe > nul
goto barra

:limpa
echo Limpando...
echo -------------------------
timeout /t 1 /nobreak > nul
cls
goto barra

:1
echo Executado com sucesso!
echo -------------------------
goto barra

:7
cls
goto barra

:2
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\notify.wav').PlaySync()"
%cor% Blue [!] Reparação de arquivos feita com sucesso!
echo -------------------------
goto barra

:lembrete
cls
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Message Nudge.wav').PlaySync()"
powershell -NoProfile -Command ^
%cor% DarkGray -------------------------
%cor% Green $([char]0x2000)Criador de Lembretes
%cor% DarkGray -------------------------
:perguntarlembrete
set /p respostaLembretes=Você quer fazer um lembrete? (S/N): 
if /I "%respostaLembretes%"=="S" (
    cls
    goto criarLembrete
) else if /I "%respostaLembretes%"=="N" (
    cls
    goto barra
) else (
    start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer '%execfile%\sound\warn3.wav').PlaySync()"
    echo Resposta inválida. Digite apenas S ou N.
    timeout /t 2 >nul
    cls
    goto perguntarlembrete
)
:criarLembrete
cls
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Hardware Fail.wav').PlaySync()"
powershell -NoProfile -Command ^
"Write-Host '-------------------------' -ForegroundColor Gray; ^
 Write-Host 'Crie um Lembrete!' -ForegroundColor Cyan; ^
 Write-Host 'Digite o conteúdo do lembrete, ele será colocado na Área de Trabalho.' -ForegroundColor DarkGray; ^
 Write-Host '-------------------------' -ForegroundColor Gray"
set "desktopPath=%USERPROFILE%\Desktop"
set "arquivoNum=1"
:checaArquivolembretes
if exist "%desktopPath%\lembrete_%arquivoNum%.txt" (
    set /a arquivoNum+=1
    goto checaArquivolembretes
)
set "arquivo=%desktopPath%\lembrete_%arquivoNum%.txt"
if not exist "%arquivo%" type nul > "%arquivo%"
start "" notepad "%arquivo%"
:espera
echo Pressione Enter para continuar...
timeout /t 99999 >nul
cls
if exist "%arquivo%" goto lembreteFinal
goto espera
:lembreteFinal
(
    echo LEMBRETE %arquivoNum%
    echo -----------------------------
    type "%arquivo%"
) > "%desktopPath%\temp_lembrete.txt"
move /y "%desktopPath%\temp_lembrete.txt" "%arquivo%" >nul
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\Windows\Media\Windows Notify Calendar.wav').PlaySync()"
powershell -NoProfile -Command ^
"Write-Host '-------------------------' -ForegroundColor Gray; ^
 Write-Host 'Lembrete Criado!' -ForegroundColor Cyan; ^
 Write-Host '-------------------------' -ForegroundColor Gray; ^
Write-Host ('Tamanho do Arquivo: ' + (Get-Item '%arquivo%').Length + ' Bytes') -ForegroundColor White; ^
Write-Host ('Nome do Arquivo: ' + (Get-Item '%arquivo%').Name) -ForegroundColor White; ^
Write-Host ('Local do Arquivo: ' + (Get-Item '%arquivo%').FullName) -ForegroundColor White"
timeout /t 10 >nul
cls
goto barra

:: Fechar Programa
:sair
start "" /min powershell -c "(New-Object Media.SoundPlayer 'C:\Windows\Media\Alarm03.wav').PlaySync()" 
%cor% Blue Tchau!
timeout /t 1 >nul
exit