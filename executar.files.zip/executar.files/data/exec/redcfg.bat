@echo off
set "execfile=%USERPROFILE%\Documents\executar.files\data\exec"
mode 70,28
chcp 65001 >nul
::REDEFINIDOR
:redef
if not exist "%execfile%\fullname" (
    type nul > "%execfile%\fullname"
)
if not exist "%execfile%\stcolor" (
    type nul > "%execfile%\stcolor"
)
cls
start "" /min powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\Windows\Media\Ring06.wav').PlaySync()"
powershell -NoProfile -Command  Write-Host '=== REDEFINIR CONFIGURAÇÕES ===' -ForegroundColor Green"
powershell -NoProfile -Command  Write-Host '=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=' -ForegroundColor DarkGray"
powershell -NoProfile -Command  Write-Host 'Selecione quais configurações você quer redefinir.' -ForegroundColor Blue"
powershell -NoProfile -Command  Write-Host 'Dois Arquivos redefiníveis: stcolor, fullname' -ForegroundColor DarkYellow"
powershell -NoProfile -Command  Write-Host '=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=' -ForegroundColor DarkGray"
echo [redstc] - Redefinir stcolor (a cor será setada para Branco)
echo [redfname] - Redefinir fullname (Executar.bat irá pedir um nome)
echo.
:delbar
set /p delput=^> 
if /i "%delput%"=="redstc" goto redstcred
if /i "%delput%"=="redfname" goto redfnamered
powershell -NoProfile -Command ^
$text='[X] Parâmetro Errado.'; ^
foreach ($c in $text.ToCharArray()) { Write-Host -NoNewline $c -ForegroundColor Red; Start-Sleep -Milliseconds 12.5 }; ^
Write-Host
timeout /t 20 >nul
goto redef
:redstcred
cls
del /f %USERPROFILE%\Documents\executar.files\data\exec\stcolor
powershell -NoProfile -Command  Write-Host 'o arquivo foi Restaurado.' -ForegroundColor Red"
timeout /t 2 >nul
goto redef
:redfnamered
cls
del /f %USERPROFILE%\Documents\executar.files\data\exec\fullname
powershell -NoProfile -Command  Write-Host 'o arquivo foi Restaurado.' -ForegroundColor Red"
timeout /t 2 >nul
goto redef